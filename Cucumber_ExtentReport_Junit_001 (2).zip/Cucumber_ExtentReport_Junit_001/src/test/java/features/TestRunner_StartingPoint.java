package features;

import java.io.File;

import org.apache.log4j.Logger;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;

//import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.cucumber.listener.ExtentProperties;
import com.cucumber.listener.Reporter;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import cucumber.api.testng.AbstractTestNGCucumberTests;
import eZLM.Automation.Accelerators.Browser;
import eZLM.Automation.Accelerators.Report;
import eZLM.Automation.Utilities.ConfiguratorFileSupport;
import features.StepDefinitions.Cucumber_Hooks;

/**
 * TestRunner - Is the class used to Run the All features files defined in
 * "src/test/resources location .
 */
/*
 * @RunWith(Cucumber.class)
 * 
 * @CucumberOptions(features={"src/test/resources/features/TLM"},format={
 * "json:target/cucumber.json","html:target/html"})
 * 
 * public class TestRunner{
 * 
 * 
 * 
 * 
 * }
 */

@RunWith(Cucumber.class)
@CucumberOptions(features = { "src/test/resources/features/Google/" }, glue = {
		"features.StepDefinitions" }, plugin = { "com.cucumber.listener.ExtentCucumberFormatter:output/report.html" })

public class TestRunner_StartingPoint extends AbstractTestNGCucumberTests {	

/*	public static Logger Log = Logger.getLogger(TestRunner_Junit.class);*/
	public static ExtentHtmlReporter extent;
	public static ExtentTest logger;
	public static boolean Cleanup=true;

	@BeforeClass
	public static void setup() {

		// Report.cleanup(); -- This is for Cleanup the Screenshots folder and Log files
		
		ExtentProperties extentProperties = ExtentProperties.INSTANCE;
		extentProperties.setReportPath("Report/myreport.html");
		

	}

	@AfterClass
	public static void teardown() {
		Reporter.loadXMLConfig(new File("src/test/resources/extent-config.xml"));
		Reporter.setSystemInfo("user", System.getProperty("user.name"));
		Reporter.setSystemInfo("os", "Mac OSX");
		// Reporter.setTestRunnerOutput("Sample test runner output message");
		for (String s : org.testng.Reporter.getOutput()) {
			Reporter.setTestRunnerOutput(s);
		}
		Report.SendReportEmail();

	}

}
