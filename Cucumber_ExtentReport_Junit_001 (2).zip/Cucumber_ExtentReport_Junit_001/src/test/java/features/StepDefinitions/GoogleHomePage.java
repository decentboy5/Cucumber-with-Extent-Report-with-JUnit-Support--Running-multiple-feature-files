package features.StepDefinitions;
import org.openqa.selenium.WebDriver;
import cucumber.api.java.en.Given;
import eZLM.Automation.Accelerators.Browser;


public class GoogleHomePage {

	public static WebDriver driver = null;

	@Given("^Launch the Browser and Navigate to google\\.com$")
	public void launch_the_Browser_and_Navigate_to_google_com() throws Throwable {

		Browser.Open("https://www.google.com");
		
		
			}

	@Given("^Enter the data in Home Page$")
	public void enter_the_data_in_Home_Page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		Browser.Type("//*[@title='Search']", "Hellooo", "Search Box");
		
	}

	@Given("^Logout$")
	public void logout() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		// driver.close();
		// Caller.Click("id=qqq", "Something wong");
		Browser.CloseAllSessions();
	}
	
	@Given("^Enter the data in Home Page Failed Case$")
	public void enter_the_data_in_Home_Page_Failed_Case() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		Browser.Type("//*[@title='WrongPath']", "Hellooo", "Search Box");
		
	}
	 

}
