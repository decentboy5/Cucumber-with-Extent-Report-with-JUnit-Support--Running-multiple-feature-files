package eZLM.Automation.Accelerators;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import eZLM.Automation.Utilities.ConfiguratorFileSupport;

public class Browser {

	public static WebDriver webdriver = null;
	private static WebDriver Driver;
	public static int SleepTime = 0;
	private static ConfiguratorFileSupport configProps = new ConfiguratorFileSupport(
			System.getProperty("user.dir") + "//" + "TLMConfiguration.properties");

	private static Logger Log = Logger.getLogger(Browser.class);

	private static HashMap<String, WebDriver> WebDriver_Instances = new HashMap<String, WebDriver>();

	/**
	 * It will launch browser and Navigate to specified URL
	 * 
	 * @param URL
	 *            - Application URL
	 */
	public static void Open(String URL) {

		DefaultBrowserInstance(ConfiguratorFileSupport.getProperty("Browser"));

		Open_Default_Session(URL);

	}

	private static void DefaultBrowserInstance(String Browser) {

		Driver = ConfigWebDriverInstance(Browser);
		if (WebDriver_Instances.size() < 1) {
			WebDriver_Instances.put("default", Driver);
		}
	}

	private static WebDriver ConfigWebDriverInstance(String BrowserName) {

		try {
			Runtime.getRuntime().exec("taskkill /F /IM chromedriver.exe");
		} catch (IOException e) {

			e.printStackTrace();
		}

		try {
			switch (BrowserName.toUpperCase()) {

			case "FIREFOX":

				FirefoxProfile specialProfile = new FirefoxProfile();
				specialProfile.setPreference("browser.helperApps.neverAsk.saveToDisk",
						"text/html;charset=iso-8859-1,application/dat,application/pdf,text/plain,text/csv,application/x-msexcel,application/excel,application/x-excel,application/octet-stream,application/download,text/x-csv");
				specialProfile.setPreference("browser.helperApps.neverAsk.openFile",
						"text/html;charset=iso-8859-1,application/dat,application/pdf,text/plain,text/csv,application/x-msexcel,application/excel,application/x-excel,application/octet-stream,application/download,text/x-csv");
				specialProfile.setPreference("browser.download.folderList", 2);
				specialProfile.setPreference("browser.download.dir", "C:\\Temp\\");
				specialProfile.setPreference("plugin.disable_full_page_plugin_for_types",
						"application/pdf,application/vnd.fdf");
				specialProfile.setPreference("browser.download.manager.alertOnEXEOpen", false);
				specialProfile.setPreference("browser.download.manager.useWindow", false);
				specialProfile.setPreference("browser.download.manager.showAlertOnComplete", false);
				specialProfile.setPreference("browser.download.manager.closeWhenDone", true);
				specialProfile.setPreference("browser.helperApps.alwaysAsk.force", false);
				specialProfile.setPreference("pdfjs.disabled", true);
				specialProfile.setAcceptUntrustedCertificates(true);
				webdriver = new FirefoxDriver(new FirefoxBinary(), specialProfile);
				Log.info("Successfully Lanched" + BrowserName + " Browser");
				break;

			case "CHROME":
				System.setProperty("webdriver.chrome.driver", "driver/chromedriver.exe");
				DesiredCapabilities capabilities = DesiredCapabilities.chrome();
				ChromeOptions options = new ChromeOptions();
				options.addArguments("test-type");
				options.addArguments("--start-maximized");
				options.addArguments("--ignore-certificate-errors");
				capabilities.setCapability(ChromeOptions.CAPABILITY, options);
				if (SleepTime > 0)
					Thread.sleep(10000);
				webdriver = new ChromeDriver(capabilities);
				Log.info("Successfully Lanched" + BrowserName + " Browser");
				break;

			default:
				Log.error(BrowserName + " is Invalid Browser Name mentioned in the \"TLMConfiguration.properties\" ");

			}
		} catch (Exception e) {
			Log.error("Exception whiling Launching the " + BrowserName + e.getMessage());
			Log.error("Failed to Launch " + BrowserName + " Browser");
			Browser.Fail("Failed to Launch " + BrowserName + " Browser");
		}

		return webdriver;

	}

	/**
	 * used to Launch new Session with the specified Name
	 * 
	 * @param sessionName
	 *            - any Name which you want to create
	 */
	public static void CreateSession(String sessionName) {

		try {
			WebDriver _Driver = ConfigWebDriverInstance(ConfiguratorFileSupport.getProperty("browser"));

			if (WebDriver_Instances.containsKey(sessionName)) {
				Browser.Fail(sessionName + " :-- Specfied Session is already exists");
			}

			WebDriver_Instances.put(sessionName, _Driver);
			Driver = _Driver;
		} catch (Exception e) {
			Log.info("Failed to Created Sesssion with the Name :" + sessionName);
		}
	}

	/**
	 * This is used to Falling the Test case. it will not execute further
	 * actions in current test case
	 * 
	 * @param Message
	 *            - Any custom message which you want to display on reports
	 */
	public static void Fail(String Message) {

		Assert.fail(Message);
	}

	/**
	 * Used to Open the newly created Session with specified URL. Before that
	 * you have to Create Session with ( Caller.CreateSession("Session Name") )
	 * 
	 * @param sessionName
	 *            : Which is used to open session
	 * 
	 * @param URL
	 *            : URL which is used to open.
	 */
	public static void OpenSession(String sessionName, String URL) {
		WebDriver driver = Driver;
		driver.get(URL);

	}

	private static void Open_Default_Session(String url) {

		try {
			
			WebDriver driver = Driver;
			driver.manage().deleteAllCookies();
			
			//driver.manage().window().maximize();
			driver.get(url);
			Log.info("Successfully Launched the Application");
		} catch (Exception e) {

		}
	}

	/**
	 * Used to close the browser session
	 * 
	 * @param Instance_name
	 *            - which session which you want to close
	 * 
	 * 
	 */
	public static void CloseSession(String SessionName) {
		try {
			WebDriver instance = null;
			if (WebDriver_Instances.containsKey(SessionName)) {
				instance = WebDriver_Instances.get(SessionName);
				instance.quit();
				WebDriver_Instances.remove(SessionName);
			} else {

				Log.info("Session instance is not exist :  " + SessionName);
			}
		} catch (Exception e) {
			Log.error("Close Session is Failed : Error is :" + e.getMessage());
			Browser.Fail("Close Session is Failed : Error is  :" + e.getMessage());
		}

	}

	/**
	 * This is for switching between two sessions
	 * 
	 * @param SessionName
	 *            : To which session you want to switch
	 */
	public static void SwitchSession(String SessionName) {

		try {
			if (WebDriver_Instances.containsKey(SessionName)) {
				WebDriver instance = WebDriver_Instances.get(SessionName);
				Driver = instance;
			}
		} catch (Exception e) {
			Log.info("Switch session command failed. Cannot switch to " + SessionName);
			Browser.Fail("Switch session command failed. Cannot switch to " + SessionName);
		}

	}

	/**
	 * Used to do type Operator on given locator.
	 * 
	 * @since It will internally do
	 *        driver.findelement("//*[text()='username']").sendKeys("sktlm@adp")
	 *        ;
	 * @param locator
	 *            : HTML locator
	 * 
	 * @param LocatorName
	 *            : any Valid Name for debugging purpose, if not, send empty
	 *            string
	 * 
	 * @Example Type("//*[text()='username']", "username text box")
	 */

	public static boolean Type(String locator, String data, String LocatorName) {

		
		boolean status = false;
		WebElement webelement = null;
		try {
			System.out.println("  ");
			By element_locator = GetLocator(locator);
			WebDriver driver = Driver;
			driver.findElement(element_locator).clear();
			driver.findElement(element_locator).sendKeys(data);
					status = true;
			Log.info("Successfully Enter the  \"" + data + "\" in : " + LocatorName);

		} catch (Exception e) {
			WebDriver driver = Driver;
			Log.error("Failed to Enter the Text in : " + LocatorName + "Locator is :" + locator);
			Report.failure(LocatorName, driver, e.getMessage());

			status = false;
		}
		if (!status) {
			//Assert.assertTrue(status);
		}
		return status;

	}

	/**
	 * Used to do Click Operator on given locator.
	 * 
	 * @see It will internally do driver.findelement("").click();
	 * @param locator
	 *            : HTML locator
	 * 
	 * @param LocatorName
	 *            : any Valid Name for debugging purpose, if not, send empty
	 *            string
	 * 
	 * @Example Click("//*[text()='Submit']", "Submit Button")
	 */
	public static boolean Click(String locator, String LocatorName) {

		System.out.println("    ");
		WebDriver driver = Driver;
		boolean status = false;
		try {
			//driver.manage().window().maximize();
			By element_locator = GetLocator(locator);
			WebDriverWait wait = new WebDriverWait(driver, 5);
			wait.until(ExpectedConditions.elementToBeClickable(element_locator));
			driver.findElement(element_locator).click();
			status = true;
			Log.info("Successfully Cliked on" + LocatorName + "Locator is :" + locator);
		} catch (Exception e) {
			String ss = "Failed to Click on ";
			ss = ss + LocatorName;
			Log.error("Failed to Click on : " + LocatorName + "Locator is :" + locator + e.getMessage());
			Report.failure(ss, driver, e.getMessage());
		}

		if (!status) {
			// Assert.fail("Failed to Click on" + LocatorName);
		}
		return status;

	}

	/**
	 * Used to do Click Operator on given locator.
	 * 
	 * @see It will internally do driver.findelement("").click();
	 * @param locator
	 *            : HTML locator
	 * 
	 * @param LocatorName
	 *            : any Valid Name for debugging purpose, if not, send empty
	 *            string
	 * 
	 * 
	 * @Example Click("//*[text()='Submit']", "Submit Button")
	 * 
	 * Click("//*[text()='{ClientName}']",,
	 */
	public static boolean Click_Param(String dynamic_locator, String Parameter, String LocatorName) {
		WebDriver driver = Driver;
		boolean status = false;
		Parameter="ClientName{:PARAM}"+"NavyATS001";
		dynamic_locator="//*[text()='{ClientName}']";
		
		try {
			if (!Parameter.isEmpty()) {
				String param_name = Parameter.split("{:PARAM}")[0];
				String param_value = Parameter.split("{:PARAM}")[1];
				dynamic_locator = dynamic_locator.replace("{" + param_name + "}", param_value);

			}

			By element_locator = GetLocator(dynamic_locator);
			WebDriverWait wait = new WebDriverWait(driver, 5);
			wait.until(ExpectedConditions.elementToBeClickable(element_locator));
			driver.findElement(element_locator).click();
			status = true;
			Log.info("Successfully Cliked on" + LocatorName + "Locator is :" + dynamic_locator);
		} catch (Exception e) {
			String ss = "Failed to Click on ";
			ss = ss + LocatorName;
			Log.error("Failed to Click on : " + LocatorName + "Locator is :" + dynamic_locator + e.getMessage());
			Report.failure(ss, driver, e.getMessage());
		}

		if (!status) {
			// Assert.fail("Failed to Click on" + LocatorName);
		}
		return status;

	}

	/**
	 * It will Check whether element is Present in the DOM .with StoponFailure
	 * 
	 * 
	 * @see it will internally do the driver.findElmenet("");
	 * 
	 * @param locator
	 *            : HTML locator
	 * 
	 * 
	 * @param LocatorName
	 *            : any Valid Name for debugging purpose, if not, send empty
	 *            string
	 *
	 * 
	 * @Example CheckElementPresent("//*[text()='username']", "UserName  Field")
	 */

	public static boolean CheckElementPresent(String locator, String LocatorName) {

		boolean status = false;
		WebDriver driver = Driver;

		try {
			By element_locator = GetLocator(locator);
			driver.findElement(element_locator);
			status = true;
			Log.info(LocatorName + " is Present in the DOM :  " + "Locator is : " + locator);
		} catch (Exception e) {
			Log.error(LocatorName + " is Not Present in the DOM " + locator);
			Log.error(e.getMessage());
			status = false;
		}
		return status;

	}

	/**
	 * It will Check whether element is Present in the DOM .with StoponFailure
	 * 
	 * 
	 * @see it will internally do the driver.findElmenet("");
	 * 
	 * @param locator
	 *            : HTML locator
	 * 
	 * 
	 * @param LocatorName
	 *            : any Valid Name for debugging purpose, if not, send empty
	 *            string
	 * @param StopOnFailure
	 *            :if you pass StopOnFailure=true and element is not visible
	 *            then we are failing the test case
	 *
	 * @Example CheckElementPresent("//*[text()='username']", "UserName  Field"
	 *          ,true)
	 */

	public static boolean CheckElementPresent(String locator, String LocatorName, boolean StoponFailure,
			String CustomErrorMessage) {

		boolean status = false;
		WebDriver driver = Driver;

		try {
			By element_locator = GetLocator(locator);
			// driver.findElement(element_locator);
			FindElement(element_locator);
			status = true;
			Log.info(LocatorName + " is Present in the DOM :  " + "Locator is : " + locator);
		} catch (Exception e) {
			Log.error(LocatorName + " is Not Present in the DOM " + locator);
			Log.error(e.getMessage());
			status = false;
			if (StoponFailure) {
				Report.failure(LocatorName, driver, e.getMessage());
			}
		}
		return status;

	}

	/**
	 * It Will Check whether element is Enabled or not
	 * 
	 * @return true if successful, else false
	 * @see (will internally will do
	 *      driver.findElement(element_locator).isEnabled())
	 * @param locator
	 *            : HTML locator
	 * 
	 * 
	 * @param LocatorName
	 *            : any Valid Name for debugging purpose
	 * 
	 * @Example CheckElementEnabled("//*[text()='username']", "UserName  Field")
	 */
	public static boolean CheckElementEnabled(String locator, String LocatorName) {

		boolean status = false;
		WebDriver driver = Driver;

		try {
			By element_locator = GetLocator(locator);
			if (driver.findElement(element_locator).isEnabled()) {
				status = true;
				Log.info("Element is Enabled on the Page : " + locator);
			}
		} catch (Exception e) {
			Log.warn(LocatorName + " is not Enabled and Locator is :" + locator);
			Log.info(e.getMessage());
			status = false;

		}
		return status;
	}

	/**
	 * It Will Check whether element is Enabled or not with StopOnFailure
	 * Parameter.
	 * 
	 * @see (will internally will do
	 *      driver.findElement(element_locator).isEnabled())
	 * @param locator
	 *            : HTML locator
	 * 
	 * 
	 * @param LocatorName
	 *            : any Valid Name for debugging purpose, if not, send empty
	 *            string
	 * @param StopOnFailure
	 *            :if you pass StopOnFailure=true and element is not visible
	 *            then we are failing the test case
	 * 
	 * @Example CheckElementEnabled("//*[text()='username']", "UserName  Field",
	 *          true)
	 */
	public static boolean CheckElementEnabled(String locator, String LocatorName, boolean StopOnFailure,
			String CustomErrorMessage) {

		boolean status = false;
		WebDriver driver = Driver;

		try {
			By element_locator = GetLocator(locator);

			if (driver.findElement(element_locator).isEnabled()) {
				status = true;
				Log.info("Element is Enabled and Locator is :  " + locator);
			}
		} catch (Exception e) {
			Log.error(LocatorName + " is Not enabled And Locator is : " + locator);
			Log.error(e.getMessage());
			status = false;
			if (StopOnFailure) {
				Report.failure(LocatorName, driver, e.getMessage());
			}
		}
		return status;

	}

	private static WebElement FindElement(final By locator) {

		WebDriver driver = Driver;

		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver);
		wait.withTimeout(60, TimeUnit.SECONDS);
		wait.pollingEvery(5, TimeUnit.SECONDS);
		wait.ignoring(NoSuchElementException.class);
		wait.until(ExpectedConditions.visibilityOfElementLocated((locator)));
		return driver.findElement(locator);

		/*
		 * final WebElement element = null; WebDriver driver = Driver; try {
		 * FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver);
		 * wait.withTimeout(60, TimeUnit.SECONDS); wait.pollingEvery(5,
		 * TimeUnit.SECONDS); wait.ignoring(NoSuchElementException.class);
		 * wait.until(ExpectedConditions.presenceOfElementLocated(locator));
		 * return driver.findElement(locator);
		 * 
		 * } catch (Exception e) { Log.error("Failed to Find element at -- : " +
		 * locator); Log.error(e.getMessage());
		 * 
		 * return element; }
		 */

	}

	/**
	 * It Will Check whether element is displayed or not with
	 * 
	 * 
	 * 
	 * @param locator
	 *            : HTML locator
	 * @return true if successful, else false
	 * 
	 * @param LocatorName
	 *            : any Valid Name for debugging purpose, if not, send empty
	 *            string
	 * 
	 * @Example CheckElementVisible("//*[text()='username']", "UserName  Field")
	 */

	public static boolean CheckElementVisible(String locator, String LocatorName) {

		boolean status = false;
		WebDriver driver = Driver;
		try {
			By element_locator = GetLocator(locator);
			status = driver.findElement(element_locator).isDisplayed();
			if (status)
				Log.info(LocatorName + " Element is displyed  :   \"" + locator);

		} catch (Exception e) {

			Log.warn(LocatorName + " Element is not displyed and locator is : \"" + locator);
			Log.info(e.getMessage());
			status = false;

		}

		return status;

	}

	/**
	 * It Will Check whether element is displayed or not with StopOnFailure
	 * Parameter.
	 * 
	 * 
	 * @param locator
	 *            : HTML locator
	 * 
	 * 
	 * @param LocatorName
	 *            : any Valid Name for debugging purpose, if not, send empty
	 *            string
	 * @param StopOnFailure
	 *            :if you pass StopOnFailure=true and element is not visible
	 *            then we are failing the test case
	 * 
	 * @Example CheckElementVisible("//*[text()='username']", "UserName  Field",
	 *          true)
	 */

	public static boolean CheckElementVisible(String locator, String LocatorName, boolean StopOnFailure) {

		boolean status = false;
		WebDriver driver = Driver;
		By element_locator = null;

		try {
			element_locator = GetLocator(locator);
			if (driver.findElement(element_locator).isDisplayed()) {
				status = true;
				Log.info("Element is Visiable on the Page :  " + locator);
			}
		} catch (Exception e) {
			Log.warn("Element is not displyed " + locator);
			Log.info(e.getMessage());
			status = false;
			if (StopOnFailure) {
				Report.failure(LocatorName, driver, e.getMessage());
			}
		}

		return status;
	}

	/**
	 * WaitForElement Method used to wait for specified number of Minutes to
	 * find any element.
	 * 
	 * @param locator
	 *            is the element locator
	 * @param Minutes
	 *            : No. of minutes you want to wait for an element. Value Should
	 *            be >=1
	 * @Example : WaitForElement("//div[text(),'Time Card']",2);
	 */

	public static boolean WaitForElement(String locator, int Minutes, String LocatorName) {

		boolean status = false;
		WebDriver driver = Driver;
		By element_locator = null;
		int retry = Minutes;
		try {
			element_locator = GetLocator(locator);
			WebDriverWait wait = new WebDriverWait(driver, 60 * retry);
			wait.until(ExpectedConditions.visibilityOfElementLocated(element_locator));
			status = true;
			Log.info("Successfully Found the Element :  " + locator);
		} catch (Exception e) {
			Log.warn("Failed to Find  " + locator);
			Log.info(e.getMessage());
			Report.failure(LocatorName, driver, e.getMessage());
			status = false;
		}
		return status;
	}

	/**
	 * Move the mouse to the middle of the element. then The element is Tcrolled
	 * into view
	 * 
	 * @param LocatorName
	 *            : any Valid Name for debugging purpose, if not, send empty
	 *            string
	 * 
	 * @return true, if successful
	 * 
	 */

	public static void MouseOver(String locator, String LocatorName) {
		WebDriver driver = Driver;
		By element_locator = GetLocator(locator);
		int retry = 60;
		try {

			WebElement element = FindElement(element_locator);

			while (retry > 0) {
				try {
					retry--;
					Actions builder = new Actions(driver);
					builder.moveToElement(element).build().perform();
					// if the testcase passed ,breaking the while loop
					break;
				} catch (StaleElementReferenceException staleElementException) {
					element = FindElement(element_locator);

				} catch (Exception e) {

					if (!(retry > 0)) {
						Log.error("Mouse action is Failed on " + LocatorName);
						Report.failure(LocatorName, driver, e.getMessage());
					}
				}
			}
		}

		catch (Exception e) {
			Log.error("Mouse action is Failed on " + LocatorName);
			Report.failure(LocatorName, driver, e.getMessage());

		}
	}

	private static By GetLocator(String locator) {

		String _locator = locator;
		String locator_type = null;

		if (locator.startsWith("/") || locator.startsWith("(") || locator.startsWith(".")) {

			return By.xpath(locator);
		} else {
			locator_type = _locator.substring(0, _locator.indexOf("="));
			_locator = locator.replace(locator_type + "=", "");

			if (locator_type.toLowerCase().contains("id")) {
				return By.id(_locator);
			} else if (locator_type.toLowerCase().contains("class")) {
				return By.className(_locator);
			} else if (locator_type.toLowerCase().contains("css")) {
				return By.cssSelector(_locator);
			} else if (locator_type.toLowerCase().contains("tagname")) {
				return By.tagName(_locator);
			} else if (locator_type.toLowerCase().contains("link")) {
				return By.linkText(_locator);
			} else if (locator_type.toLowerCase().contains("xpath")) {
				return By.xpath(_locator);
			} else if (locator_type.toLowerCase().contains("name")) {
				return By.name(_locator);
			} else {
				Log.error("Invalid element locator Passed :" + locator);
				Assert.fail("Invalid Element Locator passed :" + locator);
				return null;

			}
		}

	}

	public static void CloseAllSessions() {

		Iterator<String> itr = null;
		try {
			Set<String> all_instances_Names = WebDriver_Instances.keySet();
			// itr = all_instances_Names.iterator();

			for (String instance_name : all_instances_Names) {
				System.out.println(instance_name + ": " + WebDriver_Instances.get(instance_name));
				WebDriver instance = WebDriver_Instances.get(instance_name);
				instance.quit();
				WebDriver_Instances.remove(instance_name);

			}
			/*
			 * while (itr.hasNext()) { String Browser_instance=itr.next();
			 * WebDriver instance = WebDriver_Instances.get(itr.next());
			 * instance.quit(); WebDriver_Instances.remove(Browser_instance); }
			 */
		} catch (Exception e) {
			Log.warn("Failed to Close the " + itr + "Session");
		}
	}
	
	
	
/** This is for Frames */
	public static void SwitchFrame(String frameName)
	{ 
		WebDriver driver = Driver; 
		try
		{
		
		WebElement webelement;
		if(frameName.toUpperCase().equalsIgnoreCase("PARENT"))
		{
			driver.switchTo().parentFrame();
		}
		else if(frameName.startsWith("index"))
		{
			frameName=frameName.replace("index=","");
			int index=Integer.parseInt(frameName);
			driver.switchTo().frame(index);
		}
		else if(!frameName.contains("="))
		{
			driver.switchTo().frame(frameName);
		}
		else 
		{
			By element_locator=GetLocator(frameName);
			webelement = FindElement(element_locator);
			driver.switchTo().frame(webelement);
		}}
		catch(Exception e)
		{
		Log.error(" Unable to find the specifid frame  " + frameName);
		Report.failure(frameName, driver, e.getMessage());
			
		}
	}

}


